[ ! "$MODPATH" ] && MODPATH=${0%/*}
#get Android version
android_version=$(getprop ro.build.version.release)
os_version=$(getprop ro.system.build.version.incremental)
var_device=$(getprop ro.product.device)
var_device_2="$(getprop ro.product.device | awk '{print toupper(substr($0,1,1)) tolower(substr($0,2))}')"
kernel=$(uname -r)

alias sh='/system/bin/sh'
prop_file="$MODPATH/system.prop"

print_modname() {

# 【本模块纯参数调音，如需引用调音文件请注明作者】
#sleep 0.4
    ui_print "═══════════════════════════════════════════════════"
    ui_print "  本模块仅适用于 小米平板 5 Pro (elish｜enuma)"
    ui_print "═══════════════════════════════════════════════════"
    sleep 0.3
    
    # 显示设备信息
    ui_print "• 设备信息检测："
    ui_print "  设备型号：$var_device_2"
    ui_print "  安卓版本：$android_version"
    ui_print "  系统版本：$os_version"
    ui_print "  内核版本：$kernel"
    sleep 1.0
    
    # 检查设备型号
    if [ "$var_device" != "elish" ] && [ "$var_device" != "enuma" ]; then
        ui_print "═══════════════════════════════════════════════════"
        ui_print "❌【严重错误】设备型号不匹配！"
        ui_print "═══════════════════════════════════════════════════"
        ui_print "  支持设备：elish 或 enuma"
        ui_print "  当前设备：$var_device"
        ui_print "═══════════════════════════════════════════════════"
        ui_print "⚠ 风险提示："
        ui_print "  1. 音频功能可能异常"
        ui_print "  2. 可能导致系统不稳定"
        ui_print "  3. 部分功能无法使用"
        ui_print "═══════════════════════════════════════════════════"
        sleep 0.3
    
        # 用户确认
        ui_print "  是否强制安装？(音量+：强制安装，音量-：取消)"
        local key_click=""
        local timeout=0
        while [ "$key_click" = "" ] && [ $timeout -lt 20 ]; do
            key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
            sleep 0.3
            timeout=$((timeout + 1))
        done
    
        if [ "$key_click" != "KEY_VOLUMEUP" ]; then
            ui_print "═══════════════════════════════════════════════════"
            ui_print "✖ 安装已取消"
            abort "  设备不兼容，安装终止"
            sleep 0.5
        fi
    
        ui_print "═══════════════════════════════════════════════════"
        ui_print "⚠ 您已选择强制安装，后果自负"
        sleep 0.5
    else
        ui_print "═══════════════════════════════════════════════════"
        ui_print "✅ 设备验证通过（$var_device）"
        sleep 0.5
    fi
    
    ui_print "═══════════════════════════════════════════════════"
    ui_print "  ⚠注意⚠：【本模块为纯参数调音，如需引用调音文件请注明作者】"
    ui_print "═══════════════════════════════════════════════════"
    ui_print "  本模块内的overlay参数、Virtual Bass，通路等文件的修改参考By"
    ui_print "  @NikoRur_QwQRuaa @Huber_HaYu @是Ray酱呀 @Sc素菜 @Hubery_Brook(Gerose)"
    ui_print "═══════════════════════════════════════════════════"
    sleep 0.5
}

set_permissions() {
    set_perm_recursive $MODPATH 0 0 0755 0644
# 设置 /system/vendor/etc 的权限和标签
    set_perm_recursive $MODPATH/system/vendor/etc 0 0 0755 0644 u:object_r:vendor_configs_file:s0
# 设置 /system/vendor/etc/audio 文件夹的权限和标签
    set_perm_recursive $MODPATH/system/vendor/etc/audio 0 0 0755 0644 u:object_r:vendor_configs_file:s0
# 设置 /system/vendor/etc/audio/audio_policy_configuration.xml 文件的权限和标签    
    set_perm $MODPATH/system/vendor/etc/audio/audio_policy_configuration.xml 0 0 0644 u:object_r:vendor_configs_file:s0
# 设置 $MODPATH/system/vendor/lib 目录的权限和标签
    set_perm_recursive $MODPATH/system/vendor/lib 0 0 0755 0755 u:object_r:same_process_hal_file:s0
# 设置 $MODPATH/system/vendor/lib64 目录的权限和标签
    set_perm_recursive $MODPATH/system/vendor/lib64 0 0 0755 0755 u:object_r:same_process_hal_file:s0    
}

Acoustics_Replace() {

    ui_print "═══════════════════════════════════════════════════"
    ui_print "  请问是否需要替换掉新版音质音效"
    ui_print "  如果需要 请按音量+键 如果不需要请按音量-"
    ui_print "  tips：替换旧版音质音效可能会导致关闭杜比后小米音效均衡器无法调用甚至可能会导致音质音效闪退"
    ui_print "═══════════════════════════════════════════════════"

    key_click=""
        while [ "$key_click" = "" ]; do
            key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
            sleep 0.2
        done
        case "$key_click" in
            "KEY_VOLUMEUP")
            ui_print "- 已选择 替换新版音质音效"
            echo "" >> "$prop_file"  # 添加空行
            echo "# Disable Automatic Scene (2)" >> "$prop_file"
            echo "ro.vendor.audio.misound.dynamic.support=false" >> "$prop_file"
            echo "persist.vendor.audio.auto.scenario=false" >> "$prop_file"
            ;;
            *)
            ui_print "- 已选择 不替换新版音质音效"
            rm -rf $MODPATH//system/product
            ;;
        esac
    
}

firmware_dsp() {

    ui_print "═══════════════════════════════════════════════════"
    ui_print "  请问是否选择优化扬声器功放DSP"
    ui_print "  本修改可以换取更优秀的输出质量，但可能会导致momo检测出magisk，请谨慎选择"
    ui_print "═══════════════════════════════════════════════════"
    ui_print "  音量+ 优化DSP 音量- 不优化DSP"
    ui_print "═══════════════════════════════════════════════════"

    key_click=""
        while [ "$key_click" = "" ]; do
            key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
            sleep 0.2
        done
        case "$key_click" in
            "KEY_VOLUMEUP")
            ui_print "- 已选择 优化扬声器功放DSP"
            sleep 0.5
            ;;
            *)
            ui_print "- 已选择 不优化扬声器功放DSP"
            rm -rf $MODPATH/system/vendor/firmware
            ;;
       esac
    
}

ull_configuation() {

    ui_print "═══════════════════════════════════════════════════"
    ui_print "  请问是否启用 OpenSL ES 超低延迟输出"
    ui_print "  在CPU负载过高时，启用此选项可能导致咔哒声，且可能导致部分问题"
    ui_print "═══════════════════════════════════════════════════"
    ui_print "  本修改可以对音游等高延迟需求应用有较大提升，且选项并不影响耗电与音质"
    ui_print "═══════════════════════════════════════════════════"
    ui_print "  音量+ 启用 音量- 不启用"
    ui_print "═══════════════════════════════════════════════════"

    key_click=""
        while [ "$key_click" = "" ]; do
            key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
            sleep 0.2
        done
        case "$key_click" in
            "KEY_VOLUMEUP")
            ui_print "- 已选择 启用超低延迟输出"
            sleep 0.5
            ;;
            *)
            ui_print "- 已选择 不启用"
            cp -rf $MODPATH/Fast/audio_policy_configuration.xml $MODPATH/system/vendor/etc/audio/audio_policy_configuration.xml
            ;;
        esac
    
}

#Virtual_Bass_Dolby_Dax
VB_Dax() {

    ui_print "═══════════════════════════════════════════════════"
    ui_print "  请问选择优化杜比音效的虚拟低频还是启用低频增强"
    ui_print "  虚拟低频可以一定程度上避免低频糊音的问题"
    ui_print "  低频增强将增强低频增益，可提供更强的沉浸感"
    ui_print "═══════════════════════════════════════════════════"
    ui_print "  音量+ 优化虚拟低频 音量- 启用低频增强"
    ui_print "═══════════════════════════════════════════════════"

    key_click=""
        while [ "$key_click" = "" ]; do
            key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
            sleep 0.2
        done
        case "$key_click" in
            "KEY_VOLUMEUP")
            ui_print "- 已选择 优化虚拟低频"
            cp -rf $MODPATH/Dax/dax-default.xml $MODPATH/system/vendor/etc/dolby/dax-default.xml
            sleep 0.5
            ;;
            *)
            ui_print "- 已选择 启用低频增强"
                ;;
        esac
    
}

Cache_Clean() {

    ui_print "═══════════════════════════════════════════════════"
    ui_print "  正在清理缓存..."

    rm -rf /data/system/package_cache
    rm -rf /data/dalvik-cache
    rm -rf /data/cache
    rm -rf $MODPATH/Fast
    rm -rf $MODPATH/Dax

    ui_print "═══════════════════════════════════════════════════"
    ui_print "  加载完成，重启以体验模块"

}
    
print_modname
set_permissions
Acoustics_Replace
firmware_dsp
ull_configuation
VB_Dax
Cache_Clean