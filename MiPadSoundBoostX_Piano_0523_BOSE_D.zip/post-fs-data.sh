#!/system/bin/sh

#post-fs-data.sh
#Overlay Test

MODDIR=${0%/*}
# 定义需要覆盖的分区映射
# 格式: "模块源目录:系统目标目录"
partitions="
$MODDIR/odm:/odm
"

# 也可以根据需要添加其他分区，如：
# $MODDIR/system:/system  (注意：system分区可能需要特殊处理)

echo "$partitions" | while IFS=: read -r mod_path sys_path; do
    [ -z "$mod_path" ] && continue
    [ ! -d "$mod_path" ] && continue
    
    find "$mod_path" -type f 2>/dev/null | while read -r file; do
        relpath="${file#$mod_path/}"
        target="$sys_path/$relpath"
        
        # 创建目标目录
        mkdir -p "$(dirname "$target")" 2>/dev/null
        
        # 执行挂载
        mount --bind "$file" "$target" 2>/dev/null && \
            echo "Mounted: $file -> $target" || \
            echo "Failed: $file -> $target"
    done
done