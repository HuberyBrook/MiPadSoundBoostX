[ ! "$MODPATH" ] && MODPATH=${0%/*}
#get Android version
android_version=$(getprop ro.build.version.release)
alias sh='/system/bin/sh'
a=$(getprop ro.system.build.version.release)
var_device="`getprop ro.product.device`"

print_modname() {

# 【本模块纯参数调音，如需引用调音文件请注明作者】
#sleep 0.4
ui_print "⚠注意⚠：【请仔细查看下面的内容】"
ui_print "————————本模块适用于KSU————————"
sleep 1.0
ui_print "————————————————————————————————————————————————————"
ui_print "本模块仅适用于小米平板5(nabu)"
ui_print "————————————————————————————————————————————————————"
sleep 1.0
ui_print "⚠注意⚠：【本模块为纯参数调音，如需引用调音文件请注明作者】"
#sleep 1.5
ui_print "————————————————————————————————————————————————————"
ui_print " 本模块内的overlay参数、Virtual Bass，通路等文件的修改By"
ui_print "-------@NikoRur_QwQRuaa @Huber_HaYu @是Ray酱呀 @Sc素菜 @Hubery_Brook(Gerose)---------"
ui_print "————————————————————————————————————————————————————"

}

set_permissions() {
    set_perm_recursive $MODPATH 0 0 0755 0644
# 设置 /system/vendor/etc 的权限和标签
    set_perm_recursive $MODPATH/system/vendor/etc 0 0 0755 0644 u:object_r:vendor_configs_file:s0
# 设置 /system/vendor/etc/audio 文件夹的权限和标签
    set_perm_recursive $MODPATH/system/vendor/etc/audio 0 0 0755 0644 u:object_r:vendor_configs_file:s0
# 设置 /system/vendor/etc/audio/audio_policy_configuration.xml 文件的权限和标签    
    set_perm $MODPATH/system/vendor/etc/audio/audio_policy_configuration.xml 0 0 0644 u:object_r:vendor_configs_file:s0
# 设置 $MODPATH/system/vendor/lib 目录的权限和标签
    set_perm_recursive $MODPATH/system/vendor/lib 0 0 0755 0755 u:object_r:same_process_hal_file:s0
# 设置 $MODPATH/system/vendor/lib64 目录的权限和标签
    set_perm_recursive $MODPATH/system/vendor/lib64 0 0 0755 0755 u:object_r:same_process_hal_file:s0    
}

Acoustics_Replace() {

ui_print "————————————————————————————————————————————————————"
ui_print "请问是否需要替换掉新版音质音效"
ui_print "如果需要 请按音量+键 如果不需要请按音量-"
ui_print "tips：替换旧版音质音效可能会导致关闭杜比后小米音效均衡器无法调用甚至可能会导致音质音效闪退"
ui_print "————————————————————————————————————————————————————"

key_click=""
    while [ "$key_click" = "" ]; do
        key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.2
    done
    case "$key_click" in
        "KEY_VOLUMEUP")
        ui_print "已选择 替换新版音质音效"
        ;;
        *)
        ui_print "已选择 不替换新版音质音效"
        rm -rf $MODPATH//system/product
        ;;
    esac
    
ui_print "————————————————————————————————————————————————————"

}

Cache_Clean() {

ui_print "正在清理缓存..."

rm -rf /data/system/package_cache
rm -rf /data/dalvik-cache
rm -rf /data/cache

ui_print "加载完成，重启以体验模块"

}
    
print_modname
set_permissions
Acoustics_Replace
Cache_Clean