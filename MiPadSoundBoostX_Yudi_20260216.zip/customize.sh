[ ! "$MODPATH" ] && MODPATH=${0%/*}
#get Android version
android_version=$(getprop ro.build.version.release)
os_version=$(getprop ro.system.build.version.incremental)
var_device=$(getprop ro.product.device)
var_device_2="$(getprop ro.product.device | awk '{print toupper(substr($0,1,1)) tolower(substr($0,2))}')"
kernel=$(uname -r)

alias sh='/system/bin/sh'
prop_file="$MODPATH/system.prop"

print_modname() {

# 【本模块纯参数调音，如需引用调音文件请注明作者】
#sleep 0.4
    ui_print "═══════════════════════════════════════════════════"
    ui_print "  本模块仅适用于 小米平板 6 Max 14 (yudi)"
    ui_print "═══════════════════════════════════════════════════"
    sleep 0.3
    
    # 显示设备信息
    ui_print "• 设备信息检测："
    ui_print "  设备型号：$var_device_2"
    ui_print "  安卓版本：$android_version"
    ui_print "  系统版本：$os_version"
    ui_print "  内核版本：$kernel"
    sleep 1.0
    
    # 检查设备型号
    if [ "$var_device" != "yudi" ]; then
        ui_print "————————————————————————————————————————————————————"
        ui_print "❌【严重错误】设备型号不匹配！"
        ui_print "————————————————————————————————————————————————————"
        ui_print "  目标设备：yudi"
        ui_print "  当前设备：$var_device"
        ui_print "————————————————————————————————————————————————————"
        ui_print "⚠ 风险提示："
        ui_print "  1. 音频功能可能异常"
        ui_print "  2. 可能导致系统不稳定"
        ui_print "  3. 部分功能无法使用"
        ui_print "═══════════════════════════════════════════════════"
        sleep 0.3
        
        # 用户确认
        ui_print "  是否强制安装？(音量+：强制安装，音量-：取消)"
        local key_click=""
        local timeout=0
        while [ "$key_click" = "" ] && [ $timeout -lt 20 ]; do
            key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
            sleep 0.3
            timeout=$((timeout + 1))
        done
        
        if [ "$key_click" != "KEY_VOLUMEUP" ]; then
            ui_print "═══════════════════════════════════════════════════"
            ui_print "✖ 安装已取消"
            abort "  设备不兼容，安装终止"
            sleep 0.5
        fi
        
        ui_print "═══════════════════════════════════════════════════"
        ui_print "⚠ 您已选择强制安装，后果自负"
        sleep 0.5
    else
        ui_print "═══════════════════════════════════════════════════"
        ui_print "✅ 设备验证通过"
        sleep 0.5
    fi
    
    ui_print "————————————————————————————————————————————————————"
    ui_print "  ⚠注意⚠：【本模块为纯参数调音，如需引用调音文件请注明作者】"
    ui_print "═══════════════════════════════════════════════════"
    ui_print "  本模块内的overlay参数、Virtual Bass，通路等文件的修改参考By"
    ui_print "  @NikoRur_QwQRuaa @Huber_HaYu @是Ray酱呀 @Sc素菜 @Hubery_Brook(Gerose)"
    ui_print "═══════════════════════════════════════════════════"
    sleep 0.5
}

set_permissions() {
    set_perm_recursive $MODPATH 0 0 0755 0644
# 设置 /system/vendor/etc 的权限和标签
    set_perm_recursive $MODPATH/system/vendor/etc 0 0 0755 0644 u:object_r:vendor_configs_file:s0
# 设置 /system/vendor/etc/audio 文件夹的权限和标签
    set_perm_recursive $MODPATH/system/vendor/etc/audio 0 0 0755 0644 u:object_r:vendor_configs_file:s0
# 设置 /system/vendor/odm/etc 文件夹的权限和标签    
    set_perm_recursive $MODPATH/system/vendor/odm/etc 0 0 0755 0644 u:object_r:vendor_configs_file:s0    
# 设置 $MODPATH/system/vendor/lib 目录的权限和标签
    set_perm_recursive $MODPATH/system/vendor/lib 0 0 0755 0755 u:object_r:same_process_hal_file:s0
# 设置 $MODPATH/system/vendor/lib64 目录的权限和标签
    set_perm_recursive $MODPATH/system/vendor/lib64 0 0 0755 0755 u:object_r:same_process_hal_file:s0    
}

#MiSound_App_Replace
Acoustics_Replace() {

    ui_print " "
    ui_print "————————————————————————————————————————————————————"
    ui_print "   请问是否替换音质音效应用"
    ui_print "————————————————————————————————————————————————————"
    sleep 0.3
    
    ui_print " "
    ui_print "📊 操作说明："
    ui_print "• 此操作将替换系统的新版音质音效应用"
    ui_print "• 使用旧版音质音效应用替代当前版本"
    ui_print " "
    
    ui_print "⚠️ 重要警告："
    ui_print "• 替换后使用杜比音效时，小米音效均衡器可能无法调用"
    ui_print "• 极端情况下可能导致音质音效设置闪退"
    ui_print " "
    
    ui_print "🔧 技术调整（测试版）："
    ui_print "• 将关闭音频自动场景切换"
    ui_print " "
    
    ui_print "═══════════════════════════════════════════════════"
    ui_print "请选择操作："
    ui_print "  [音量+] 替换新版音质音效"
    ui_print "  [音量-] 保留当前系统配置"
    ui_print "═══════════════════════════════════════════════════"

    key_click=""
        while [ "$key_click" = "" ]; do
            key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
            sleep 0.2
        done
        case "$key_click" in
            "KEY_VOLUMEUP")
            ui_print "- 已选择 替换新版音质音效"
            echo "" >> "$prop_file"  # 添加空行
            echo "# Disable Automatic Scene (2)" >> "$prop_file"
            echo "ro.vendor.audio.misound.dynamic.support=false" >> "$prop_file"
            echo "persist.vendor.audio.auto.scenario=false" >> "$prop_file"
            sleep 0.5
            ;;
            *)
            ui_print "- 已选择 保留当前系统配置"
            rm -rf $MODPATH//system/product
            sleep 0.5
            ;;
        esac
    sleep 0.5
}

#CS35L43_DSP
firmware_dsp() {

    ui_print " "
    ui_print "————————————————————————————————————————————————————"
    ui_print "   请问时候替换扬声器功放DSP配置文件"
    ui_print "————————————————————————————————————————————————————"
    sleep 0.3
    
    ui_print " "
    ui_print "🎵 功能描述："
    ui_print "• 优化扬声器数字信号处理器(DSP)配置"
    ui_print "• 调整功放参数，提升音频输出质量"
    ui_print "• 改善扬声器动态响应和音质清晰度"
    ui_print " "
    
    ui_print "⚠️ 风险提示："
    ui_print "• 修改DSP固件可能被安全应用检测"
    ui_print "• Momo等检测工具可能识别为Magisk模块"
    ui_print "• 某些银行/支付应用可能触发安全警告"
    ui_print " "
    
    ui_print "═══════════════════════════════════════════════════"
    ui_print "是否应用扬声器DSP优化？"
    ui_print "  [音量+] 应用优化（提升音质）"
    ui_print "  [音量-] 跳过优化（保持兼容）"
    ui_print "═══════════════════════════════════════════════════"

    key_click=""
        while [ "$key_click" = "" ]; do
            key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
            sleep 0.2
        done
        case "$key_click" in
            "KEY_VOLUMEUP")
            ui_print "- 已选择  应用优化（提升音质）"
            sleep 0.5
            ;;
            *)
            ui_print "- 已选择 跳过优化（保持兼容）"
            rm -rf $MODPATH/system/vendor/firmware
            sleep 0.5
            ;;
        esac
    sleep 0.5
}

#New_Dolby_Dax
My_Dax() {

    ui_print " "
    ui_print "————————————————————————————————————————————————————"
    ui_print "   是否应用新的测试版杜比配置"
    ui_print "————————————————————————————————————————————————————"
    sleep 0.3
    
    ui_print " "
    ui_print "📢 替换说明："
    ui_print "• 基于2016+0715规格配置重构的杜比音效"
    ui_print "• 优化场景参数，增强低频表现力"
    ui_print "• 提供更丰富的虚拟低频增益效果"
    ui_print " "
    
    ui_print "🔧 技术特性："
    ui_print "• 杜比配置部分采用 dada 扬声器 Bass 参数"
    ui_print "• 重新调校的音频场景算法"
    ui_print "• 增强的低频响应和虚拟低音增益"
    ui_print "• 可能作为未来版本的唯一杜比配置"
    ui_print " "
        
    ui_print "═══════════════════════════════════════════════════"
    ui_print "  请选择是否应用此杜比配置："
    ui_print "  [音量+] 应用测试版杜比音效配置"
    ui_print "  [音量-] 跳过，使用默认配置"
    ui_print "═══════════════════════════════════════════════════"

    key_click=""
        while [ "$key_click" = "" ]; do
            key_click="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
            sleep 0.2
        done
        case "$key_click" in
            "KEY_VOLUMEUP")
            ui_print "- 已选择 应用测试版杜比音效配置"
            cp -rf $MODPATH/Dax/dax-default.xml $MODPATH/system/vendor/etc/dolby/dax-default.xml
            cp -rf $MODPATH/Dax/odm/dax-default.xml $MODPATH/odm/etc/dolby/dax-default.xml
            cp -rf $MODPATH/Dax/lib/soundfx $MODPATH/system/vendor/lib/soundfx
            cp -rf $MODPATH/Dax/lib64 $MODPATH/system/vendor
            sleep 0.5
            ;;
            *)
            ui_print "- 已选择 跳过，使用默认配置"
            sleep 0.5
            ;;
        esac
    
    sleep 0.5
}

Cache_Clean() {

    ui_print " "
    ui_print "————————————————————————————————————————————————————"
    ui_print "   正在清理系统缓存清理与模块临时配置文件"
    ui_print "————————————————————————————————————————————————————"
    sleep 0.3
    
    ui_print "⚠️ 清理影响："
    ui_print "• 首次重启时间会稍长（系统重建缓存）"
    ui_print "• 不会删除用户数据和个人文件"
    ui_print " "
    
    ui_print "🔄 正在执行清理操作..."
    
    ui_print "⏳ 步骤 1/4: 清理应用包缓存..."
    rm -rf /data/system/package_cache
    ui_print "   ✓ 应用包缓存已清理"
    sleep 0.3
    ui_print "⏳ 步骤 2/4: 清理Dalvik缓存..."
    rm -rf /data/dalvik-cache
    ui_print "   ✓ Dalvik缓存已标记清理"
    sleep 0.3
    ui_print "⏳ 步骤 3/4: 清理系统缓存..."
    rm -rf /data/cache
    ui_print "   ✓ 系统缓存已清理"
    sleep 0.3
    ui_print "⏳ 步骤 4/4: 清理模块临时文件..."
    rm -rf $MODPATH/Dax
    ui_print "   ✓ 模块临时文件已清理"
    sleep 0.5
    
    ui_print "————————————————————————————————————————————————————"
    ui_print "✅ 缓存清理完成！"
    ui_print "————————————————————————————————————————————————————"
    
    ui_print "🎯 重要提示："
    ui_print "• 请立即重启设备以完成优化"
    ui_print "• 重启后体验完整的音频优化效果"
    
    ui_print "═══════════════════════════════════════════════════"
    ui_print "   模块安装完成！请重启设备 🚀"
    ui_print "═══════════════════════════════════════════════════"
}
    
print_modname
set_permissions
Acoustics_Replace
firmware_dsp
My_Dax
Cache_Clean