#!/system/bin/sh

#post-fs-data.sh
#Overlay Test

MODDIR=${0%/*}
MOD_BASE="$MODDIR/odm"
SYS_BASE="/odm"

find "$MOD_BASE" -type f | while read -r file; do

    relpath="${file#$MOD_BASE/}"
    target="$SYS_BASE/$relpath"

    mkdir -p "$(dirname "$target")"

    mount --bind "$file" "$target"
done